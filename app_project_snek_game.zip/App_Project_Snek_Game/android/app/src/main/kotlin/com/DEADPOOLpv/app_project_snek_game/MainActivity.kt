package com.DEADPOOLpv.app_project_snek_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
